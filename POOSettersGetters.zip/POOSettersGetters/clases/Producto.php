<?php
class Productos{
    public int $id;
    public string $nombre;
    public int $unidades;
    private float $precio;
    private $iva=0.21;

    public function __constructor(int $id, string $nombre, int $unidades, float $iva)();
        $this->id=$id
        $this->nombre=$nombre
        $this->unidades=$unidades
        $this->iva=$iva
}
    #setters
    public function setId(int $id):void{
      $this->id=$id
    }
    public function setNombre(int $nombre):void{
      $this->nombre=$nombre
    }
    public function setUnidades(int $unidades):void{
      $this->unidades=$unidades
    }
    public function setIva(int $iva):void{
      $this->id=$iva
    }
    #getters

    public function setId():int{
        return $this->id=$id
     }
     public function setNombre(int $nombre):string{
        return $this->nombre=$nombre
     }
     public function setUnidades(int $unidades):int{
        return $this->unidades=$unidades
     }
     public function setIva(int $iva):void{
        return $this->id=$iva
     }

     $total->$unidades*$precio*$iva
     echo "el total es: ".($unidades*$precio*$iva)
?>