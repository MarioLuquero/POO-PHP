<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>POO Setters y Getters</h2>
    <?php
    require_once('./clases/Productos.php')
    $productos=new Producto(100, "camisa", 5, 7.99);
    $producto1->setPrecio(7.95);
    echo $producto1->getPrecio();
    ?>
</body>
</html>